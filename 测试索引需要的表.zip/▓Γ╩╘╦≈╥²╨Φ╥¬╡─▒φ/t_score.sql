/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : localhost:3306
 Source Schema         : db1

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 06/02/2021 16:33:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_score
-- ----------------------------
DROP TABLE IF EXISTS `t_score`;
CREATE TABLE `t_score`  (
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `score` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`sid`, `cid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_score
-- ----------------------------
INSERT INTO `t_score` VALUES (101, 1, 98);
INSERT INTO `t_score` VALUES (101, 2, 98);
INSERT INTO `t_score` VALUES (101, 3, 76);
INSERT INTO `t_score` VALUES (102, 1, 87);
INSERT INTO `t_score` VALUES (102, 2, 89);
INSERT INTO `t_score` VALUES (103, 1, 98);

SET FOREIGN_KEY_CHECKS = 1;
